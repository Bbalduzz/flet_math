library flet_math;

export "../src/create_control.dart" show createControl, ensureInitialized;
